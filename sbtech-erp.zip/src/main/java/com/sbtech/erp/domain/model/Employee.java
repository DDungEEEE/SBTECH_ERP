package com.sbtech.erp.domain.model;

import com.sbtech.erp.domain.EmployeePosition;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
@AllArgsConstructor
public class Employee {
    private final Long employeeId;
    private final String employeeName;
    private final String employeeEmail;
    private final EmployeePosition employeePosition;
}
