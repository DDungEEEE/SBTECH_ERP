package com.sbtech.erp.domain;

public enum EmployeePosition {
    INTERN,
    STAFF,
    ASSISTANCE_MANAGER,
    EXECUTIVE;
}
