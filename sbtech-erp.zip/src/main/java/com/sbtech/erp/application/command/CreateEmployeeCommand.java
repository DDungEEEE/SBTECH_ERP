package com.sbtech.erp.application.command;

import com.sbtech.erp.domain.EmployeePosition;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class CreateEmployeeCommand {
    private final String  employeeName;
    private final String employeeEmail;
    private final EmployeePosition employeePosition;
}
