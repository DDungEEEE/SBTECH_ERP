package com.sbtech.erp.application.port.in;

import com.sbtech.erp.application.command.CreateEmployeeCommand;
import com.sbtech.erp.domain.model.Employee;


public interface EmployeeUseCase {
    Employee createEmployee(CreateEmployeeCommand command);
}
