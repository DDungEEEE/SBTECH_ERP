package com.sbtech.erp.application.service;

import com.sbtech.erp.application.command.CreateEmployeeCommand;
import com.sbtech.erp.application.port.in.EmployeeUseCase;
import com.sbtech.erp.application.port.out.EmployeeRepositoryPort;
import com.sbtech.erp.domain.model.Employee;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class EmployeeService implements EmployeeUseCase {
    private final EmployeeRepositoryPort employeeRepositoryPort;

    @Override
    public Employee createEmployee(CreateEmployeeCommand command) {
        Employee employee = Employee.builder()
                .employeeEmail(command.getEmployeeEmail())
                .employeeName(command.getEmployeeName())
                .employeePosition(command.getEmployeePosition())
                .build();

        return employeeRepositoryPort.save(employee);
    }
}
