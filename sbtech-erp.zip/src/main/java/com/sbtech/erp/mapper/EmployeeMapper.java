package com.sbtech.erp.mapper;

import com.sbtech.erp.adapter.out.persistence.entity.EmployeeEntity;
import com.sbtech.erp.domain.model.Employee;
import org.springframework.stereotype.Component;

@Component
public class EmployeeMapper {
    public Employee toDomain(EmployeeEntity entity){
        return Employee.builder()
                .employeeName(entity.getEmployeeName())
                .employeeEmail(entity.getEmployeeEmail())
                .employeePosition(entity.getEmployeePosition())
                .build();
    }

    public EmployeeEntity toEntity(Employee employee){
        return EmployeeEntity.builder()
                .employeeName(employee.getEmployeeName())
                .employeePosition(employee.getEmployeePosition())
                .employeeEmail(employee.getEmployeeEmail())
                .build();
    }
}
