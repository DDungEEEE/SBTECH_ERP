package com.sbtech.erp.auth.application.port.in;

public interface AccessTokenUseCase {
    void addBlacklist(String accessToken);
    boolean isBlacklisted(String accessToken);
}
