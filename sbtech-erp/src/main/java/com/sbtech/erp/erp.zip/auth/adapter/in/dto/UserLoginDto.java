package com.sbtech.erp.auth.adapter.in.dto;


public record UserLoginDto(String loginId, String password) {
}
