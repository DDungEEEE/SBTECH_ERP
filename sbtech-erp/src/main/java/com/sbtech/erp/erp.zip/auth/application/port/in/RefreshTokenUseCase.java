package com.sbtech.erp.auth.application.port.in;

import com.sbtech.erp.auth.adapter.in.dto.JwtToken;

public interface RefreshTokenUseCase {
    String reissue(String loginId, String refreshToken);
    void save(String loginId, String refreshToken);
    void delete(String loginId);
}
