package com.sbtech.erp.products.domain;

public enum ProductStatus {
    ACTIVE,
    INACTIVE
}
