package com.sbtech.erp.accounting.domain.code;

public enum PostingStatus { DRAFT, POSTED }