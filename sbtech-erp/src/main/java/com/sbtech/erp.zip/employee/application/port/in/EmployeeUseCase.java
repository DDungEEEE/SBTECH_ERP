package com.sbtech.erp.employee.application.port.in;

import com.sbtech.erp.employee.adapter.in.dto.EmployeeApprovalReq;
import com.sbtech.erp.employee.adapter.in.dto.EmployeeCreateReq;
import com.sbtech.erp.employee.domain.model.Employee;
import com.sbtech.erp.employee.domain.model.Rank;

import java.util.List;

public interface EmployeeUseCase {
    Employee register(String name, String loginId, String password);

    List<Employee> findAllEmployees();

    Employee findById(Long id);
    Employee findById(Long id, String message);

    boolean checkLoginIdDuplicated(String loginId);

    List<Employee> getPendingEmployees();

    Employee requestLeave(Long id);

    Employee approveLeave(Long id);

    Employee requestRetire(Long id);

    Employee approveRetire(Long id);


}
