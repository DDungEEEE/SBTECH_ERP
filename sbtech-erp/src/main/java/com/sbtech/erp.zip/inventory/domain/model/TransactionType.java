package com.sbtech.erp.inventory.domain.model;

public enum TransactionType {
    IN,
    OUT,
    ADJUST
}
