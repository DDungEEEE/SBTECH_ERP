package com.sbtech.erp.task.domain.model;

public enum TaskPriority {
    HIGH, MEDIUM, LOW
}
